Place your logo here as 'getsitelogo.png'
